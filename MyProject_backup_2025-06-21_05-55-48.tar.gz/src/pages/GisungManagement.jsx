import React, { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  IconButton,
  Chip,
  Card,
  CardContent,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  InputAdornment
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Visibility as ViewIcon,
  TrendingUp as TrendingUpIcon,
  AttachMoney as MoneyIcon
} from '@mui/icons-material';
import { getSites } from '../api/sites';

const GisungManagement = () => {
  const [sites, setSites] = useState([]);
  const [selectedSite, setSelectedSite] = useState(null);
  const [gisungData, setGisungData] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [dialogMode, setDialogMode] = useState('add'); // 'add' or 'edit'
  const [currentGisung, setCurrentGisung] = useState({});

  useEffect(() => {
    fetchSites();
    // 임시 데이터 로드
    loadGisungData();
  }, []);

  const fetchSites = async () => {
    try {
      const sitesData = await getSites();
      setSites(sitesData);
    } catch (error) {
      console.error("Error fetching sites:", error);
    }
  };

  const loadGisungData = () => {
    // 임시 데이터
    const tempData = [
      {
        id: 1,
        siteId: 'site1',
        siteName: '서울 아파트 신축공사',
        gisungDate: '2024-01-15',
        gisungAmount: 50000000,
        progressRate: 25,
        status: '승인대기',
        description: '1차 기성'
      },
      {
        id: 2,
        siteId: 'site2',
        siteName: '부산 상가 건설',
        gisungDate: '2024-01-20',
        gisungAmount: 75000000,
        progressRate: 40,
        status: '승인완료',
        description: '2차 기성'
      }
    ];
    setGisungData(tempData);
  };

  const handleAddGisung = () => {
    setDialogMode('add');
    setCurrentGisung({});
    setOpenDialog(true);
  };

  const handleEditGisung = (gisung) => {
    setDialogMode('edit');
    setCurrentGisung(gisung);
    setOpenDialog(true);
  };

  const handleDeleteGisung = (id) => {
    if (window.confirm('기성 데이터를 삭제하시겠습니까?')) {
      setGisungData(prev => prev.filter(item => item.id !== id));
    }
  };

  const handleSaveGisung = () => {
    if (dialogMode === 'add') {
      const newGisung = {
        id: Date.now(),
        ...currentGisung,
        status: '승인대기'
      };
      setGisungData(prev => [...prev, newGisung]);
    } else {
      setGisungData(prev => prev.map(item => 
        item.id === currentGisung.id ? currentGisung : item
      ));
    }
    setOpenDialog(false);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case '승인완료': return 'success';
      case '승인대기': return 'warning';
      case '반려': return 'error';
      default: return 'default';
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('ko-KR').format(amount);
  };

  return (
    <Box sx={{ p: 3, bgcolor: '#1a1d21', minHeight: '100vh' }}>
      <Grid container spacing={3}>
        {/* 헤더 */}
        <Grid item xs={12}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
            <Typography variant="h4" fontWeight="bold" sx={{ color: '#fff' }}>
              기성관리
            </Typography>
            <Button
              variant="contained"
              startIcon={<AddIcon />}
              onClick={handleAddGisung}
              sx={{ bgcolor: '#1976d2' }}
            >
              기성 등록
            </Button>
          </Box>
        </Grid>

        {/* 통계 카드 */}
        <Grid item xs={12} md={3}>
          <Card sx={{ bgcolor: '#232734', color: '#fff' }}>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                총 기성 건수
              </Typography>
              <Typography variant="h4">
                {gisungData.length}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card sx={{ bgcolor: '#232734', color: '#fff' }}>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                총 기성 금액
              </Typography>
              <Typography variant="h4">
                {formatCurrency(gisungData.reduce((sum, item) => sum + item.gisungAmount, 0))}원
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card sx={{ bgcolor: '#232734', color: '#fff' }}>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                승인 대기
              </Typography>
              <Typography variant="h4">
                {gisungData.filter(item => item.status === '승인대기').length}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card sx={{ bgcolor: '#232734', color: '#fff' }}>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                승인 완료
              </Typography>
              <Typography variant="h4">
                {gisungData.filter(item => item.status === '승인완료').length}
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        {/* 기성 목록 테이블 */}
        <Grid item xs={12}>
          <Paper elevation={3} sx={{ bgcolor: '#232734', color: '#fff' }}>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ color: '#fff', fontWeight: 'bold' }}>현장명</TableCell>
                    <TableCell sx={{ color: '#fff', fontWeight: 'bold' }}>기성일자</TableCell>
                    <TableCell sx={{ color: '#fff', fontWeight: 'bold' }}>기성금액</TableCell>
                    <TableCell sx={{ color: '#fff', fontWeight: 'bold' }}>진행률</TableCell>
                    <TableCell sx={{ color: '#fff', fontWeight: 'bold' }}>상태</TableCell>
                    <TableCell sx={{ color: '#fff', fontWeight: 'bold' }}>비고</TableCell>
                    <TableCell sx={{ color: '#fff', fontWeight: 'bold' }}>작업</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {gisungData.map((gisung) => (
                    <TableRow key={gisung.id} hover>
                      <TableCell sx={{ color: '#fff' }}>{gisung.siteName}</TableCell>
                      <TableCell sx={{ color: '#fff' }}>{gisung.gisungDate}</TableCell>
                      <TableCell sx={{ color: '#fff' }}>
                        {formatCurrency(gisung.gisungAmount)}원
                      </TableCell>
                      <TableCell sx={{ color: '#fff' }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Typography>{gisung.progressRate}%</Typography>
                          <TrendingUpIcon sx={{ fontSize: 16 }} />
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={gisung.status}
                          color={getStatusColor(gisung.status)}
                          size="small"
                        />
                      </TableCell>
                      <TableCell sx={{ color: '#fff' }}>{gisung.description}</TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', gap: 1 }}>
                          <IconButton
                            size="small"
                            onClick={() => handleEditGisung(gisung)}
                            sx={{ color: '#1976d2' }}
                          >
                            <EditIcon />
                          </IconButton>
                          <IconButton
                            size="small"
                            onClick={() => handleDeleteGisung(gisung.id)}
                            sx={{ color: '#f44336' }}
                          >
                            <DeleteIcon />
                          </IconButton>
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>
        </Grid>
      </Grid>

      {/* 기성 등록/수정 다이얼로그 */}
      <Dialog open={openDialog} onClose={() => setOpenDialog(false)} maxWidth="md" fullWidth>
        <DialogTitle sx={{ bgcolor: '#232734', color: '#fff' }}>
          {dialogMode === 'add' ? '기성 등록' : '기성 수정'}
        </DialogTitle>
        <DialogContent sx={{ bgcolor: '#232734', color: '#fff' }}>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12} md={6}>
              <FormControl fullWidth>
                <InputLabel sx={{ color: '#fff' }}>현장 선택</InputLabel>
                <Select
                  value={currentGisung.siteId || ''}
                  onChange={(e) => setCurrentGisung(prev => ({ ...prev, siteId: e.target.value }))}
                  sx={{ color: '#fff' }}
                >
                  {sites.map((site) => (
                    <MenuItem key={site.id} value={site.id}>
                      {site.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="기성일자"
                type="date"
                value={currentGisung.gisungDate || ''}
                onChange={(e) => setCurrentGisung(prev => ({ ...prev, gisungDate: e.target.value }))}
                InputLabelProps={{ shrink: true }}
                sx={{ input: { color: '#fff' }, label: { color: '#fff' } }}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="기성금액"
                type="number"
                value={currentGisung.gisungAmount || ''}
                onChange={(e) => setCurrentGisung(prev => ({ ...prev, gisungAmount: Number(e.target.value) }))}
                InputProps={{
                  endAdornment: <InputAdornment position="end">원</InputAdornment>,
                }}
                sx={{ input: { color: '#fff' }, label: { color: '#fff' } }}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="진행률"
                type="number"
                value={currentGisung.progressRate || ''}
                onChange={(e) => setCurrentGisung(prev => ({ ...prev, progressRate: Number(e.target.value) }))}
                InputProps={{
                  endAdornment: <InputAdornment position="end">%</InputAdornment>,
                }}
                sx={{ input: { color: '#fff' }, label: { color: '#fff' } }}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="비고"
                multiline
                rows={3}
                value={currentGisung.description || ''}
                onChange={(e) => setCurrentGisung(prev => ({ ...prev, description: e.target.value }))}
                sx={{ input: { color: '#fff' }, label: { color: '#fff' } }}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ bgcolor: '#232734' }}>
          <Button onClick={() => setOpenDialog(false)} sx={{ color: '#fff' }}>
            취소
          </Button>
          <Button onClick={handleSaveGisung} variant="contained">
            저장
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default GisungManagement; 