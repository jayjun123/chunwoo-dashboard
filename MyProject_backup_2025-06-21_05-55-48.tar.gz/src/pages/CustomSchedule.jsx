import React, { useState, useMemo, useEffect } from 'react';
import { Box, Typography, Button, TextField, IconButton } from '@mui/material';
import CustomCalendar from '../components/CustomCalendar';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { collection, getDocs, doc, setDoc, deleteDoc, query, where, onSnapshot, writeBatch, addDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { useDispatch } from 'react-redux';
import { setTodayCount, setTodayItems } from '../store/dashboardSlice';
import { auth } from '../firebase';

function isInMonth(site, year, month) {
  if (!site.startDate || !site.endDate) return false;
  const s = new Date(site.startDate);
  const e = new Date(site.endDate);
  const first = new Date(year, month, 1);
  const last = new Date(year, month + 1, 0);
  return !(e < first || s > last);
}

const CustomSchedule = () => {
  const dispatch = useDispatch();
  const today = new Date();
  const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
  const [year, setYear] = useState(today.getFullYear());
  const [month, setMonth] = useState(today.getMonth());
  const [calendarItems, setCalendarItems] = useState({}); // 로컬 상태
  const [savedItems, setSavedItems] = useState({}); // Firebase에 저장된 상태
  const [popupOpen, setPopupOpen] = useState(false);
  const [popupDate, setPopupDate] = useState(null);
  const [popupTitle, setPopupTitle] = useState('');
  const [popupType, setPopupType] = useState('일정');
  const [popupDesc, setPopupDesc] = useState('');
  const [selectedItems, setSelectedItems] = useState([]); // [{date, id}]
  const [editPopup, setEditPopup] = useState({ open: false, item: null, date: null });
  const [isSaved, setIsSaved] = useState(false);
  const [sites, setSites] = useState([]);

  // 현장 데이터 Firestore에서 불러오기
  useEffect(() => {
    const fetchSites = async () => {
      try {
        console.log('Firebase에서 현장 데이터 불러오는 중...');
        const snapshot = await getDocs(collection(db, 'sites'));
        const sitesData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        console.log('Firebase에서 불러온 현장 데이터:', sitesData);
        setSites(sitesData);
      } catch (error) {
        console.error('Firebase 현장 데이터 불러오기 실패:', error);
        setSites([]); // 오류 시 빈 배열로 설정
      }
    };
    fetchSites();
  }, []);

  // 공사기간(착공일~준공예정일)이 현재 월에 포함된 현장만 필터링
  const filteredSites = useMemo(
    () => {
      const filtered = sites.filter(site => isInMonth(site, year, month));
      console.log('Firebase에서 필터링된 현장:', filtered);
      return filtered;
    },
    [sites, year, month]
  );

  // 드래그앤드롭 핸들러
  const onDragStart = (result) => {
    console.log('드래그 시작:', result);
    const { source, draggableId } = result;
    console.log('드래그 소스:', source);
    console.log('드래그 ID:', draggableId);
  };

  const onDragEnd = (result) => {
    console.log('드래그 종료:', result);
    
    if (!result.destination) {
      console.log('드롭 위치가 없음');
      return;
    }

    const { source, destination } = result;
    console.log('소스:', source);
    console.log('목적지:', destination);

    // 현장 리스트에서 달력으로 드래그
    if (source.droppableId === 'siteList' && destination.droppableId !== 'siteList') {
      const siteIndex = source.index;
      const site = filteredSites[siteIndex];
      console.log('드래그된 현장:', site);
      
      if (!site) {
        console.log('현장 데이터가 없음');
        return;
      }

      const newItem = {
        id: `site-${site.id}-${Date.now()}`,
        text: site.name,
        type: '현장',
        desc: `${site.name} - ${site.status}`,
        siteId: site.id,
        createdAt: new Date().toISOString()
      };

      console.log('새로 생성된 아이템:', newItem);

      setCalendarItems(prev => {
        const newItems = { ...prev };
        if (!newItems[destination.droppableId]) {
          newItems[destination.droppableId] = [];
        }
        newItems[destination.droppableId].splice(destination.index, 0, newItem);
        console.log('업데이트된 달력 아이템:', newItems);
        return newItems;
      });
    }
    // 달력 내에서 이동
    else if (source.droppableId !== 'siteList' && destination.droppableId !== 'siteList') {
      if (source.droppableId === destination.droppableId) {
        // 같은 날짜 내에서 순서 변경
        const items = Array.from(calendarItems[source.droppableId] || []);
        const [reorderedItem] = items.splice(source.index, 1);
        items.splice(destination.index, 0, reorderedItem);
        
        setCalendarItems(prev => ({
          ...prev,
          [source.droppableId]: items
        }));
      } else {
        // 다른 날짜로 이동
        const sourceItems = Array.from(calendarItems[source.droppableId] || []);
        const destItems = Array.from(calendarItems[destination.droppableId] || []);
        const [movedItem] = sourceItems.splice(source.index, 1);
        destItems.splice(destination.index, 0, movedItem);
        
        setCalendarItems(prev => ({
          ...prev,
          [source.droppableId]: sourceItems,
          [destination.droppableId]: destItems
        }));
      }
    }
  };

  // 3. 팝업 오픈 핸들러
  const handleOpenPopup = (dateStr) => {
    if (!dateStr) return;
    setPopupOpen(true);
    setPopupDate(dateStr);
    setPopupTitle('');
    setPopupType('일정');
    setPopupDesc('');
  };
  const handleClosePopup = () => setPopupOpen(false);

  // 4. 팝업에서 추가 버튼 클릭 시 해당 날짜 셀에 항목 추가
  const handleAddSchedule = () => {
    if (!popupTitle.trim()) return;
    const items = calendarItems[popupDate] || [];
    setCalendarItems({
      ...calendarItems,
      [popupDate]: [...items, { id: 'schedule-' + Date.now(), text: popupTitle, type: popupType, desc: popupDesc }]
    });
    setPopupOpen(false);
  };

  // 5. 항목 클릭(터치) 시 선택/해제
  const handleItemClick = (date, id) => {
    setSelectedItems(prev => {
      const exists = prev.find(sel => sel.date === date && sel.id === id);
      if (exists) return prev.filter(sel => !(sel.date === date && sel.id === id));
      return [...prev, { date, id }];
    });
  };

  // 6. 더블클릭(길게터치) 시 팝업
  let touchTimer = null;
  const handleItemDoubleClick = (date, item) => {
    setEditPopup({ open: true, item, date });
  };
  const handleItemTouchStart = (date, item) => {
    touchTimer = setTimeout(() => setEditPopup({ open: true, item, date }), 600);
  };
  const handleItemTouchEnd = () => {
    clearTimeout(touchTimer);
  };

  // 일정 데이터 Firestore에서 불러오기
  useEffect(() => {
    const fetchSchedules = async () => {
      try {
        console.log('Firebase에서 일정 데이터 불러오는 중...');
        
        // 현재 사용자 정보 가져오기
        const user = auth.currentUser;
        if (!user) {
          console.log('사용자가 로그인되지 않았습니다.');
          return;
        }

        const snapshot = await getDocs(collection(db, 'schedules'));
        const schedulesData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        
        // 날짜별로 일정 그룹화
        const groupedSchedules = {};
        schedulesData.forEach(schedule => {
          if (schedule.date) {
            if (!groupedSchedules[schedule.date]) {
              groupedSchedules[schedule.date] = [];
            }
            groupedSchedules[schedule.date].push(schedule);
          }
        });
        
        console.log('Firebase에서 불러온 일정 데이터:', groupedSchedules);
        setCalendarItems(groupedSchedules);
        
      } catch (error) {
        console.error('Firebase 일정 데이터 불러오기 실패:', error);
        setCalendarItems({});
      }
    };
    
    fetchSchedules();
  }, []);

  // 저장 버튼
  const handleSave = async () => {
    try {
      console.log('Firebase에 일정 저장 중...');
      
      // 현재 사용자 정보 가져오기
      const user = auth.currentUser;
      if (!user) {
        console.error('사용자가 로그인되지 않았습니다.');
        return;
      }

      // 기존 일정 데이터 삭제
      const existingSchedules = await getDocs(collection(db, 'schedules'));
      const deletePromises = existingSchedules.docs.map(doc => 
        deleteDoc(doc.ref)
      );
      await Promise.all(deletePromises);

      // 새 일정 데이터 저장
      const savePromises = Object.entries(calendarItems).map(([date, items]) => {
        if (items && items.length > 0) {
          return items.map(item => 
            addDoc(collection(db, 'schedules'), {
              ...item,
              date,
              userId: user.uid,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString()
            })
          );
        }
        return [];
      }).flat();

      await Promise.all(savePromises);
      
      console.log('Firebase에 일정 저장 완료');
      setIsSaved(true);
      
      // 성공 메시지 표시
      alert('일정이 Firebase에 저장되었습니다!');
      
    } catch (error) {
      console.error('Firebase 일정 저장 실패:', error);
      alert('일정 저장에 실패했습니다: ' + error.message);
    }
  };

  // 8. 삭제 버튼
  const handleDeleteSelected = async () => {
    if (selectedItems.length === 0) {
      alert('삭제할 항목을 선택해주세요.');
      return;
    }

    if (!window.confirm(`선택된 ${selectedItems.length}개 항목을 삭제하시겠습니까?`)) {
      return;
    }

    try {
      console.log('Firebase에서 선택된 항목 삭제 중...');
      
      // Firebase에서 선택된 항목들 삭제
      const deletePromises = selectedItems.map(item => {
        const docRef = doc(db, 'schedules', item.id);
        return deleteDoc(docRef);
      });
      
      await Promise.all(deletePromises);
      
      // 로컬 상태에서도 제거
      const newCalendarItems = { ...calendarItems };
      selectedItems.forEach(item => {
        if (newCalendarItems[item.date]) {
          newCalendarItems[item.date] = newCalendarItems[item.date].filter(
            calItem => calItem.id !== item.id
          );
        }
      });
      
      setCalendarItems(newCalendarItems);
      setSelectedItems([]);
      
      console.log('Firebase에서 항목 삭제 완료');
      alert('선택된 항목이 Firebase에서 삭제되었습니다!');
      
    } catch (error) {
      console.error('Firebase 항목 삭제 실패:', error);
      alert('항목 삭제에 실패했습니다: ' + error.message);
    }
  };

  // 9. 엑셀 내보내기
  const handleExcel = () => {
    const rows = [];
    const currentMonth = month + 1;
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    // 해당 월의 모든 날짜에 대해 데이터 수집
    for (let day = 1; day <= daysInMonth; day++) {
      const date = `${year}-${String(currentMonth).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const items = savedItems[date] || [];
      
      items.forEach(item => {
        rows.push({
          날짜: date,
          제목: item.text,
          유형: item.type || '',
          상태: item.status || '',
          설명: item.desc || '',
          생성일: item.createdAt || ''
        });
      });
    }

    // CSV 형식으로 변환
    const headers = ['날짜', '제목', '유형', '상태', '설명', '생성일'];
    const csvContent = [
      headers.join(','),
      ...rows.map(row => headers.map(header => row[header]).join(','))
    ].join('\n');

    // 임시로 콘솔에 출력 (실제로는 파일 다운로드)
    console.log('엑셀 내보내기 데이터:', csvContent);
    alert('엑셀 데이터가 준비되었습니다. (콘솔에서 확인 가능)');
  };

  return (
    <DragDropContext onDragStart={onDragStart} onDragEnd={onDragEnd}>
      <Box sx={{
        display: 'flex',
        flexDirection: { xs: 'column', md: 'row' },
        gap: { xs: 2, md: 3 },
        p: { xs: 2, md: 3 },
        minHeight: '100vh',
        bgcolor: '#0f172a',
        color: '#fff'
      }}>
        {/* 좌측 현장 리스트 */}
        <Box sx={{
          width: { xs: '100%', md: '220px' },
          minWidth: { xs: 'auto', md: '170px' },
          flexShrink: 0,
          display: 'flex',
          flexDirection: 'column',
          gap: { xs: 1, md: 2 },
          bgcolor: '#1e293b',
          borderRadius: { xs: 2, md: 4 },
          p: { xs: 1.5, md: 3 },
          height: { xs: 'auto', md: 'calc(100vh - 48px)' },
          position: { xs: 'relative', md: 'sticky' },
          top: { xs: 'auto', md: 24 },
        }}>
          <Typography variant="h5" sx={{ 
            color: '#fff', 
            fontWeight: 700, 
            mb: { xs: 1, md: 2 }, 
            textAlign: 'left',
            fontSize: { xs: '1.2rem', md: '1.5rem' }
          }}>
            공사현황
          </Typography>
          <Typography sx={{ 
            color: '#3b82f6', 
            fontWeight: 600, 
            borderBottom: '2px solid #3b82f6', 
            pb: 0.5, 
            mb: { xs: 2, md: 4 }, 
            fontSize: { xs: '0.9rem', md: '1.1rem' }, 
            textAlign: 'left' 
          }}>
            진행중 현장 LIST
          </Typography>
          <Droppable droppableId="siteList"
            renderClone={(provided, snapshot, rubric) => (
              <Box
                ref={provided.innerRef}
                {...provided.draggableProps}
                {...provided.dragHandleProps}
                sx={{
                  mb: { xs: 0.5, md: 1 },
                  p: { xs: 0.75, md: 1 },
                  bgcolor: '#3b82f6',
                  color: '#fff',
                  borderRadius: 1,
                  fontWeight: 500,
                  fontSize: { xs: '0.8rem', md: '0.9rem' },
                  boxShadow: '0 8px 24px rgba(0,0,0,0.4)',
                  cursor: 'grabbing',
                  border: '2px solid #3b82f6',
                  transition: 'all 0.2s',
                  width: '180px',
                  zIndex: 99999,
                  position: 'fixed',
                  pointerEvents: 'none',
                  transform: 'rotate(5deg)',
                  opacity: 0.9,
                }}
              >
                {filteredSites[rubric.source.index]?.name?.slice(0,7)}({filteredSites[rubric.source.index]?.status})
              </Box>
            )}
          >
            {(provided, snapshot) => (
              <Box
                ref={provided.innerRef}
                {...provided.droppableProps}
                sx={{
                  flex: 1,
                  display: 'flex',
                  flexDirection: 'column',
                  gap: { xs: 0.5, md: 1 },
                  minHeight: { xs: '200px', md: 'auto' },
                  bgcolor: snapshot.isDraggingOver ? '#1e293b' : 'transparent',
                  borderRadius: 1,
                  p: snapshot.isDraggingOver ? 1 : 0,
                  border: snapshot.isDraggingOver ? '2px dashed #3b82f6' : 'none',
                  transition: 'all 0.2s',
                }}
              >
                {filteredSites.map((site, idx) => (
                  <Draggable key={site.id} draggableId={`siteList-${site.id}`} index={idx}>
                    {(provided, snapshot) => (
                      <Box
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        {...provided.dragHandleProps}
                        sx={{
                          mb: { xs: 0.5, md: 1 },
                          p: { xs: 0.75, md: 1 },
                          bgcolor: snapshot.isDragging ? '#3b82f6' : '#181c24',
                          color: '#fff',
                          borderRadius: 1,
                          fontWeight: 500,
                          fontSize: { xs: '0.8rem', md: '0.9rem' },
                          boxShadow: snapshot.isDragging ? '0 8px 24px rgba(0,0,0,0.4)' : 0,
                          cursor: snapshot.isDragging ? 'grabbing' : 'grab',
                          border: '1px solid #3b82f6',
                          transition: 'all 0.2s',
                          transform: snapshot.isDragging ? 'rotate(2deg) scale(1.02)' : 'none',
                          opacity: snapshot.isDragging ? 0.8 : 1,
                          '&:hover': {
                            bgcolor: snapshot.isDragging ? '#3b82f6' : '#1e293b',
                            transform: snapshot.isDragging ? 'rotate(2deg) scale(1.02)' : 'scale(1.02)',
                          }
                        }}
                      >
                        {site.name.slice(0,7)}({site.status})
                      </Box>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </Box>
            )}
          </Droppable>
        </Box>
        {/* 우측 달력 */}
        <Box sx={{
          flex: 1,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'stretch',
          bgcolor: '#181c24',
          borderRadius: { xs: 2, md: 4 },
          p: { xs: 1, md: 3 },
          width: '100%',
          minWidth: 0,
          minHeight: { xs: 'auto', md: 'calc(100vh - 48px)' },
          boxSizing: 'border-box',
          justifyContent: 'flex-start',
        }}>
          <Box sx={{ 
            flex: 1, 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            width: '100%',
            height: '100%'
          }}>
            <CustomCalendar
              year={year}
              month={month}
              calendarItems={calendarItems}
              onDragEnd={onDragEnd}
              onPrevMonth={() => setMonth(m => m === 0 ? 11 : m - 1)}
              onNextMonth={() => setMonth(m => m === 11 ? 0 : m + 1)}
              onDateClick={handleOpenPopup}
              selectedItems={selectedItems}
              onItemClick={handleItemClick}
              onItemDoubleClick={handleItemDoubleClick}
              onItemTouchStart={handleItemTouchStart}
              onItemTouchEnd={handleItemTouchEnd}
              onDeleteSelected={handleDeleteSelected}
              onSave={handleSave}
              onExcel={handleExcel}
              sx={{
                width: '100%',
                height: '100%',
                '& .calendar-grid': {
                  gap: { xs: '2px', md: '5px' }
                },
                '& .calendar-cell': {
                  p: { xs: 0.5, md: 1 },
                  minHeight: { xs: '60px', md: '100px' }
                }
              }}
            />
          </Box>
        </Box>
      </Box>
      {popupOpen && (
        <Box onClick={handleClosePopup} sx={{ position: 'fixed', top:0, left:0, width:'100vw', height:'100vh', bgcolor:'rgba(0,0,0,0.4)', zIndex: 2000, display:'flex', alignItems:'center', justifyContent:'center' }}>
          <Box onClick={e=>e.stopPropagation()} sx={{ minWidth:340, bgcolor:'#232837', borderRadius:3, p:3, boxShadow:5, position:'relative' }}>
            <IconButton onClick={handleClosePopup} sx={{ position:'absolute', top:8, right:8, color:'#fff' }}>X</IconButton>
            <Typography variant="h6" sx={{ color:'#fff', mb:2 }}>새 일정 추가</Typography>
            <TextField label="제목" value={popupTitle} onChange={e=>setPopupTitle(e.target.value)} fullWidth sx={{ mb:2, input:{color:'#fff'}, label:{color:'#fff'} }} autoFocus/>
            <TextField select label="유형" value={popupType} onChange={e=>setPopupType(e.target.value)} fullWidth sx={{ mb:2, input:{color:'#fff'}, label:{color:'#fff'} }} SelectProps={{ native:true }}>
              <option value="일정">일정</option>
              <option value="지원">지원</option>
              <option value="회의">회의</option>
              <option value="입찰">입찰</option>
              <option value="점검">점검</option>
              <option value="기타">기타</option>
            </TextField>
            <TextField label="설명" value={popupDesc} onChange={e=>setPopupDesc(e.target.value)} fullWidth multiline rows={3} sx={{ mb:2, input:{color:'#fff'}, label:{color:'#fff'} }}/>
            <Button variant="contained" color="primary" onClick={handleAddSchedule} fullWidth>추가</Button>
          </Box>
        </Box>
      )}
      {editPopup.open && (
        <Box onClick={() => setEditPopup({ ...editPopup, open: false })} sx={{ position: 'fixed', top:0, left:0, width:'100vw', height:'100vh', bgcolor:'rgba(0,0,0,0.4)', zIndex: 2000, display:'flex', alignItems:'center', justifyContent:'center' }}>
          <Box onClick={e=>e.stopPropagation()} sx={{ minWidth:340, bgcolor:'#232837', borderRadius:3, p:3, boxShadow:5, position:'relative' }}>
            <IconButton onClick={(e) => { e.stopPropagation(); setEditPopup({ ...editPopup, open: false }); }} sx={{ position:'absolute', top:8, right:8, color:'#fff' }}>X</IconButton>
            <Typography variant="h6" sx={{ color:'#fff', mb:2 }}>일정 수정</Typography>
            <TextField label="제목" value={editPopup.item?.text} onChange={(e) => setEditPopup({ ...editPopup, item: { ...editPopup.item, text: e.target.value } })} fullWidth sx={{ mb:2, input:{color:'#fff'}, label:{color:'#fff'} }} autoFocus/>
            <TextField select label="유형" value={editPopup.item?.type} onChange={(e) => setEditPopup({ ...editPopup, item: { ...editPopup.item, type: e.target.value } })} fullWidth sx={{ mb:2, input:{color:'#fff'}, label:{color:'#fff'} }} SelectProps={{ native:true }}>
              <option value="일정">일정</option>
              <option value="지원">지원</option>
              <option value="회의">회의</option>
              <option value="입찰">입찰</option>
              <option value="점검">점검</option>
              <option value="기타">기타</option>
            </TextField>
            <TextField label="설명" value={editPopup.item?.desc} onChange={(e) => setEditPopup({ ...editPopup, item: { ...editPopup.item, desc: e.target.value } })} fullWidth multiline rows={3} sx={{ mb:2, input:{color:'#fff'}, label:{color:'#fff'} }}/>
            <Button variant="contained" color="primary" onClick={(e) => { e.stopPropagation(); setCalendarItems({ ...calendarItems, [editPopup.date]: [...(calendarItems[editPopup.date] || []), editPopup.item] }); setEditPopup({ ...editPopup, open: false }); }} fullWidth>저장</Button>
          </Box>
        </Box>
      )}
    </DragDropContext>
  );
};

export default CustomSchedule; 