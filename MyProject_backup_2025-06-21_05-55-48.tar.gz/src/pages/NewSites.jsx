import React, { useState, useEffect, useMemo } from 'react';
import { Grid, Paper, Tabs, Tab, TextField, List, ListItemButton, ListItemText, Button, IconButton, Typography, Box, FormControl, Select, MenuItem, Checkbox, FormControlLabel } from '@mui/material';
import StarIcon from '@mui/icons-material/Star';
import StarBorderIcon from '@mui/icons-material/StarBorder';
import DeleteIcon from '@mui/icons-material/Delete';
import { getSites, addSite, updateSite, deleteSite } from '../api/sites';
import { useNavigate } from 'react-router-dom';

const STATUS_OPTIONS = ['진행', '예정', '완료', '보류'];
const CONTRACT_TYPE_OPTIONS = ['관급', '사급', '일반', '하도급'];

const initialFormState = {
  name: '',
  status: '예정',
  contractType: '관급',
  subcontractGuardian: false,
  installment: '',
  contractAmount: '',
  advance: '',
  totalProgress: '',
  address: '',
  startDate: '',
  endDate: '',
  companyName: '',
  manager: '',
  phone: '',
  team: '',
  desc: '',
  isFavorite: false,
  items: [],
};

const NewSites = () => {
  const [sites, setSites] = useState([]);
  const [selectedSite, setSelectedSite] = useState(null);
  const [form, setForm] = useState(initialFormState);
  const [statusTab, setStatusTab] = useState('진행');
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetchSites();
  }, []);

  useEffect(() => {
    if (selectedSite) {
      setForm({
        ...initialFormState,
        ...selectedSite,
        startDate: selectedSite.startDate ? selectedSite.startDate.split('T')[0] : '',
        endDate: selectedSite.endDate ? selectedSite.endDate.split('T')[0] : '',
      });
    } else {
      setForm(initialFormState);
    }
  }, [selectedSite]);

  const fetchSites = async () => {
    try {
      const sitesData = await getSites();
      setSites(sitesData);
    } catch (error) {
      console.error("Error fetching sites:", error);
    }
  };

  const filteredSites = useMemo(() => {
    return sites
      .filter(site => site.status === statusTab)
      .filter(site =>
        site.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (site.manager && site.manager.toLowerCase().includes(searchTerm.toLowerCase()))
      );
  }, [sites, statusTab, searchTerm]);

  const handleSelectSite = (site) => {
    setSelectedSite(site);
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
  };
  
  const handleItemsChange = (index, field, value) => {
    const newItems = [...form.items];
    newItems[index][field] = value;
    setForm(prev => ({ ...prev, items: newItems }));
  };

  const handleAddItem = () => {
    setForm(prev => ({ ...prev, items: [...(prev.items || []), { name: '', quantity: '', price: '' }] }));
  };
  
  const handleRemoveItem = (index) => {
    const newItems = form.items.filter((_, i) => i !== index);
    setForm(prev => ({ ...prev, items: newItems }));
  };

  const handleNewSite = () => {
    setSelectedSite(null);
    setForm(initialFormState);
  };
  
  const handleFavorite = (isFavorite) => {
    setForm(prev => ({...prev, isFavorite}));
  };
  
  const handleSave = async () => {
    try {
      if (selectedSite) {
        await updateSite(selectedSite.id, form);
      } else {
        await addSite(form);
      }
      fetchSites();
      handleNewSite();
    } catch (error) {
      console.error("Failed to save site:", error);
    }
  };
  
  const handleDelete = async () => {
    if (selectedSite) {
      try {
        await deleteSite(selectedSite.id);
        fetchSites();
        handleNewSite();
      } catch (error) {
        console.error("Failed to delete site:", error);
      }
    }
  };

  const handleGisung = () => {
    navigate('/gisung');
  }

  return (
    <Box sx={{ 
      display: 'flex', 
      flexDirection: { xs: 'column', md: 'row' },
      height: { xs: 'auto', md: 'calc(100vh - 64px - 52px)' }, 
      bgcolor: '#1a1d21', 
      p: 2, 
      gap: 2, 
      overflow: { xs: 'visible', md: 'hidden' }
    }}>
      {/* Left Panel - 현장 목록 */}
      <Paper elevation={3} sx={{ 
        width: { xs: '100%', md: '25%' }, 
        minWidth: { md: '250px' }, 
        height: { xs: '300px', md: '100%' },
        display: 'flex', 
        flexDirection: 'column', 
        bgcolor: '#232734', 
        p: 2, 
        borderRadius: 2 
      }}>
        <Tabs
          value={statusTab}
          onChange={(e, v) => setStatusTab(v)}
          variant="fullWidth"
          sx={{
            mb: 2, minHeight: 'auto',
            '& .MuiTabs-flexContainer': { justifyContent: 'space-between' },
            '& .MuiTab-root': { minWidth: 0, px: 1, py: 0.5, fontSize: '0.8rem', fontWeight: 'bold' }
          }}
        >
          {STATUS_OPTIONS.map(opt => <Tab key={opt} label={opt} value={opt} />)}
        </Tabs>
        <TextField
          placeholder="현장명, 담당자 검색"
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
          variant="outlined"
          size="small"
          sx={{ mb: 2, input: { color: '#fff' }, fieldset: { borderColor: '#444' } }}
        />
        <List sx={{ overflowY: 'auto', flex: 1 }}>
          {filteredSites.map(site => (
            <ListItemButton key={site.id} selected={selectedSite?.id === site.id} onClick={() => handleSelectSite(site)} sx={{ mb: 1, borderRadius: 1 }}>
              <ListItemText primary={site.name} secondary={site.status} />
            </ListItemButton>
          ))}
        </List>
      </Paper>

      {/* Center Panel - 현장 상세 정보 */}
      <Paper elevation={3} sx={{ 
        flex: 1, 
        display: 'flex', 
        flexDirection: 'column', 
        bgcolor: '#232734', 
        p: 3, 
        borderRadius: 2, 
        minWidth: 0,
        height: { xs: 'auto', md: '100%' }
      }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3, flexWrap: 'wrap', gap: 1 }}>
          <Typography variant="h5" fontWeight="bold">현장 상세 정보</Typography>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Button variant="contained" onClick={handleNewSite} size="small">+ 새현장</Button>
            <Button variant="outlined" size="small">전체 List</Button>
          </Box>
          <IconButton onClick={() => handleFavorite(!form.isFavorite)}>
            {form.isFavorite ? <StarIcon sx={{ color: 'gold' }} /> : <StarBorderIcon />}
          </IconButton>
        </Box>
        
        <Box sx={{ overflowY: 'auto', pr: 1, flex: 1 }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={8}>
              <Typography variant="caption" display="block" sx={{mb: 0.5, textAlign: 'left'}}>현장명</Typography>
              <TextField name="name" value={form.name || ''} onChange={handleChange} fullWidth size="small" />
            </Grid>
            <Grid item xs={12} sm={4} sx={{alignSelf: 'flex-end'}}>
              <FormControl fullWidth size="small">
                <Select name="status" value={form.status} onChange={handleChange}>{STATUS_OPTIONS.map(opt => <MenuItem key={opt} value={opt}>{opt}</MenuItem>)}</Select>
              </FormControl>
            </Grid>

            <Grid item xs={12} container spacing={2} alignItems="flex-end">
              <Grid item>
                <Typography variant="caption" display="block" sx={{mb: 0.5, textAlign: 'left'}}>계약구분</Typography>
                <FormControl size="small" sx={{minWidth: 150}}><Select name="contractType" value={form.contractType} onChange={handleChange}>{CONTRACT_TYPE_OPTIONS.map(opt => <MenuItem key={opt} value={opt}>{opt}</MenuItem>)}</Select></FormControl>
              </Grid>
              <Grid item>
                <FormControlLabel control={<Checkbox name="subcontractGuardian" checked={form.subcontractGuardian || false} onChange={handleChange} />} label="하도급지킴이" />
              </Grid>
              {(form.contractType === '하도급' || form.contractType === '일반') && (
              <Grid item>
                <Typography variant="caption" display="block" sx={{mb: 0.5, textAlign: 'left'}}>차수</Typography>
                <TextField name="installment" value={form.installment || ''} onChange={handleChange} size="small" sx={{width: 100}} InputProps={{ endAdornment: '차' }} />
              </Grid>
              )}
            </Grid>

            <Grid item xs={12} sm={4}>
              <Typography variant="caption" display="block" sx={{mb: 0.5, textAlign: 'left'}}>계약금액</Typography>
              <TextField name="contractAmount" value={form.contractAmount || ''} onChange={handleChange} fullWidth size="small" />
            </Grid>
            <Grid item xs={12} sm={4}>
              <Typography variant="caption" display="block" sx={{mb: 0.5, textAlign: 'left'}}>선급금</Typography>
              <TextField name="advance" value={form.advance || ''} onChange={handleChange} fullWidth size="small" />
            </Grid>
            <Grid item xs={12} sm={4}>
              <Typography variant="caption" display="block" sx={{mb: 0.5, textAlign: 'left'}}>누계기성</Typography>
              <TextField name="totalProgress" value={form.totalProgress || ''} onChange={handleChange} fullWidth size="small" />
            </Grid>

            <Grid item xs={12}>
              <Typography variant="caption" display="block" sx={{mb: 0.5, textAlign: 'left'}}>착공주소</Typography>
              <TextField name="address" value={form.address || ''} onChange={handleChange} fullWidth size="small" />
            </Grid>

            <Grid item xs={12} sm={6}>
              <Typography variant="caption" display="block" sx={{mb: 0.5, textAlign: 'left'}}>착공일</Typography>
              <TextField name="startDate" type="date" value={form.startDate || ''} onChange={handleChange} fullWidth size="small" InputLabelProps={{ shrink: true }}/>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="caption" display="block" sx={{mb: 0.5, textAlign: 'left'}}>준공예정일</Typography>
              <TextField name="endDate" type="date" value={form.endDate || ''} onChange={handleChange} fullWidth size="small" InputLabelProps={{ shrink: true }}/>
            </Grid>

            <Grid item xs={12} sm={4}>
              <Typography variant="caption" display="block" sx={{mb: 0.5, textAlign: 'left'}}>회사명</Typography>
              <TextField name="companyName" value={form.companyName || ''} onChange={handleChange} fullWidth size="small" />
            </Grid>
            <Grid item xs={12} sm={4}>
              <Typography variant="caption" display="block" sx={{mb: 0.5, textAlign: 'left'}}>소장</Typography>
              <TextField name="manager" value={form.manager || ''} onChange={handleChange} fullWidth size="small" />
            </Grid>
             <Grid item xs={12} sm={4}>
              <Typography variant="caption" display="block" sx={{mb: 0.5, textAlign: 'left'}}>연락처</Typography>
              <TextField name="phone" value={form.phone || ''} onChange={handleChange} fullWidth size="small" />
            </Grid>

            <Grid item xs={12} sm={6}>
              <Typography variant="caption" display="block" sx={{mb: 0.5, textAlign: 'left'}}>시공팀</Typography>
              <TextField name="team" value={form.team || ''} onChange={handleChange} fullWidth size="small" />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="caption" display="block" sx={{mb: 0.5, textAlign: 'left'}}>기타사항</Typography>
              <TextField name="desc" value={form.desc || ''} onChange={handleChange} fullWidth size="small" />
            </Grid>
          </Grid>
        </Box>

        <Box sx={{ mt: 'auto', pt: 2, display: 'flex', justifyContent: 'flex-end', gap: 1, flexWrap: 'wrap' }}>
          <Button variant="contained" color="primary" onClick={handleSave}>저장하기</Button>
          <Button variant="outlined" color="secondary" onClick={handleDelete} disabled={!selectedSite}>삭제</Button>
          <Button variant="contained" color="success" onClick={handleGisung} disabled={!selectedSite}>기성현황</Button>
        </Box>
      </Paper>

      {/* Right Panel - 물량 내역 */}
      <Paper elevation={3} sx={{ 
        width: { xs: '100%', md: '30%' }, 
        minWidth: { md: '280px' }, 
        height: { xs: '300px', md: '100%' },
        display: 'flex', 
        flexDirection: 'column', 
        bgcolor: '#232734', 
        p: 3, 
        borderRadius: 2 
      }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2, flexWrap: 'wrap' }}>
          <Typography variant="h5" fontWeight="bold">물량 내역</Typography>
          <Button variant="outlined" onClick={handleAddItem}>품목추가</Button>
        </Box>
        <Box sx={{ display: 'flex', gap: 1, mb: 1, color: 'text.secondary', borderBottom: 1, borderColor: 'divider', pb: 1 }}>
          <Typography sx={{ width: '40%', fontWeight: 'bold' }}>항목</Typography>
          <Typography sx={{ width: '20%', fontWeight: 'bold' }}>물량</Typography>
          <Typography sx={{ width: '30%', fontWeight: 'bold' }}>단가</Typography>
        </Box>
        <Box sx={{ flex: 1, overflowY: 'auto' }}>
          {(form.items || []).map((item, index) => (
            <Box key={index} sx={{ display: 'flex', gap: 1, mb: 1, alignItems: 'center', flexWrap: 'wrap' }}>
              <TextField value={item.name} onChange={(e) => handleItemsChange(index, 'name', e.target.value)} size="small" sx={{ flex: '1 1 120px' }} placeholder="항목"/>
              <TextField value={item.quantity} onChange={(e) => handleItemsChange(index, 'quantity', e.target.value)} size="small" sx={{ flex: '1 1 60px' }} placeholder="물량"/>
              <TextField value={item.price} onChange={(e) => handleItemsChange(index, 'price', e.target.value)} size="small" sx={{ flex: '1 1 80px' }} placeholder="단가"/>
              <IconButton onClick={() => handleRemoveItem(index)} size="small"><DeleteIcon /></IconButton>
            </Box>
          ))}
        </Box>
      </Paper>
    </Box>
  );
};

export default NewSites;
