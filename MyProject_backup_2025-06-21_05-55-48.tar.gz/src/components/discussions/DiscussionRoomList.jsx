import React, { useEffect, useState } from 'react';
import { Box, Card, CardContent, Typography, Button, Grid, IconButton, Tooltip, Badge, Dialog, DialogTitle, DialogContent, DialogActions, TextField, InputAdornment, Select, MenuItem } from '@mui/material';
import { collection, query, orderBy, onSnapshot, doc, deleteDoc, updateDoc, where, getDocs } from 'firebase/firestore';
import { db } from '../../firebase';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import TableViewIcon from '@mui/icons-material/TableView';
import ChatIcon from '@mui/icons-material/Chat';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import LockIcon from '@mui/icons-material/Lock';
import LockOpenIcon from '@mui/icons-material/LockOpen';
import SearchIcon from '@mui/icons-material/Search';
import { useAuth } from '../../contexts/AuthContext';
import jsPDF from 'jspdf';
import * as XLSX from 'xlsx';

const DiscussionRoomList = ({ onSelectRoom }) => {
  const [rooms, setRooms] = useState([]);
  const [messages, setMessages] = useState({});
  const [editDialog, setEditDialog] = useState(false);
  const [editRoom, setEditRoom] = useState(null);
  const [editName, setEditName] = useState('');
  const [editSite, setEditSite] = useState('');
  const [editPassword, setEditPassword] = useState('');
  const [passwordDialog, setPasswordDialog] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [selectedRoomForPassword, setSelectedRoomForPassword] = useState(null);
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState('recent');
  const { currentUser } = useAuth();
  const isAdmin = currentUser?.grade === '마스터' || currentUser?.grade === '관리자';

  useEffect(() => {
    const q = query(collection(db, 'discussionRooms'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const roomList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setRooms(roomList);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const unsubscribes = rooms.map(room => {
      const q = query(collection(db, 'discussions'), orderBy('createdAt', 'desc'));
      return onSnapshot(q, (snapshot) => {
        const msgs = snapshot.docs.filter(doc => doc.data().roomId === room.id).map(doc => doc.data());
        setMessages(prev => ({ ...prev, [room.id]: msgs }));
      });
    });
    return () => unsubscribes.forEach(unsub => unsub());
  }, [rooms]);

  // 검색/정렬 적용
  const filteredRooms = rooms
    .filter(room => room.name.toLowerCase().includes(search.toLowerCase()) || room.siteName.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => {
      if (sort === 'recent') return b.createdAt?.seconds - a.createdAt?.seconds;
      if (sort === 'count') return (messages[b.id]?.length || 0) - (messages[a.id]?.length || 0);
      return 0;
    });

  const handleDelete = async (roomId) => {
    console.log('삭제 버튼 클릭됨, roomId:', roomId);
    
    if (!window.confirm('정말로 이 대화방을 삭제하시겠습니까?\n관련된 모든 메시지도 함께 삭제됩니다.')) {
      console.log('사용자가 삭제를 취소함');
      return;
    }
    
    try {
      console.log('삭제 시작:', roomId);
      
      // 1. 관련된 모든 메시지 먼저 삭제
      const messagesQuery = query(collection(db, 'discussions'), where('roomId', '==', roomId));
      const messagesSnapshot = await getDocs(messagesQuery);
      
      console.log(`삭제할 메시지 수: ${messagesSnapshot.docs.length}개`);
      
      if (messagesSnapshot.docs.length > 0) {
        const deletePromises = messagesSnapshot.docs.map(doc => {
          console.log('메시지 삭제 중:', doc.id);
          return deleteDoc(doc.ref);
        });
        await Promise.all(deletePromises);
        console.log('메시지 삭제 완료');
      }
      
      // 2. 대화방 삭제
      console.log('대화방 삭제 중:', roomId);
      await deleteDoc(doc(db, 'discussionRooms', roomId));
      console.log('대화방 삭제 완료');
      
      // 3. 로컬 상태 강제 업데이트
      console.log('로컬 상태 업데이트 중...');
      setRooms(prevRooms => {
        const newRooms = prevRooms.filter(room => room.id !== roomId);
        console.log('업데이트된 대화방 수:', newRooms.length);
        return newRooms;
      });
      
      setMessages(prevMessages => {
        const newMessages = { ...prevMessages };
        delete newMessages[roomId];
        console.log('메시지 상태에서 제거됨:', roomId);
        return newMessages;
      });
      
      console.log('삭제 완료!');
      alert(`대화방과 관련 메시지 ${messagesSnapshot.docs.length}개가 성공적으로 삭제되었습니다.`);
      
    } catch (error) {
      console.error('대화방 삭제 중 오류 발생:', error);
      console.error('오류 상세:', error.code, error.message);
      alert(`삭제 중 오류가 발생했습니다: ${error.message}`);
    }
  };

  const handleEdit = (room) => {
    setEditRoom(room);
    setEditName(room.name);
    setEditSite(room.siteName);
    setEditPassword(room.password || '');
    setEditDialog(true);
  };

  const handleEditSave = async () => {
    if (!editRoom) return;
    await updateDoc(doc(db, 'discussionRooms', editRoom.id), {
      name: editName,
      siteName: editSite,
      password: editPassword
    });
    setEditDialog(false);
    setEditRoom(null);
  };

  const handlePasswordEnter = (room) => {
    setSelectedRoomForPassword(room);
    setPasswordInput('');
    setPasswordDialog(true);
  };

  const handlePasswordCheck = () => {
    if (selectedRoomForPassword.password === passwordInput) {
      onSelectRoom(selectedRoomForPassword);
      setPasswordDialog(false);
    } else {
      alert('비밀번호가 틀렸습니다.');
    }
  };

  // PDF 내보내기
  const handleExportPDF = (room) => {
    const msgs = messages[room.id] || [];
    const doc = new jsPDF();
    
    // 제목
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text(`${room.name} (${room.siteName}) 대화방`, 20, 20);
    
    // 정보
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(`총 메시지 수: ${msgs.length}개`, 20, 30);
    doc.text(`생성일: ${room.createdAt?.toDate?.().toLocaleDateString() || '날짜 없음'}`, 20, 35);
    doc.text(`비밀번호: ${room.password ? '있음' : '없음'}`, 20, 40);
    
    // 구분선
    doc.line(20, 45, 190, 45);
    
    // 메시지 목록
    let yPosition = 55;
    doc.setFontSize(9);
    
    msgs.reverse().forEach((msg, idx) => {
      if (yPosition > 270) {
        doc.addPage();
        yPosition = 20;
      }
      
      const author = msg.author || '익명';
      const content = msg.content || '';
      const date = msg.createdAt?.toDate?.().toLocaleString() || '';
      const files = msg.files?.map(f => f.name).join(', ') || '';
      
      // 작성자와 날짜
      doc.setFont('helvetica', 'bold');
      doc.text(`${author} (${date})`, 20, yPosition);
      yPosition += 5;
      
      // 내용
      doc.setFont('helvetica', 'normal');
      const lines = doc.splitTextToSize(content, 160);
      lines.forEach(line => {
        if (yPosition > 270) {
          doc.addPage();
          yPosition = 20;
        }
        doc.text(line, 20, yPosition);
        yPosition += 4;
      });
      
      // 파일 정보
      if (files) {
        yPosition += 2;
        doc.setFont('helvetica', 'italic');
        doc.text(`첨부파일: ${files}`, 20, yPosition);
        yPosition += 4;
      }
      
      yPosition += 8;
    });
    
    doc.save(`${room.name}_${room.siteName}_채팅내역.pdf`);
  };

  // 엑셀 내보내기
  const handleExportExcel = (room) => {
    const msgs = messages[room.id] || [];
    const data = msgs.map((msg, idx) => ({
      '번호': idx + 1,
      '작성자': msg.author || '익명',
      '내용': msg.content || '',
      '첨부파일': msg.files?.map(f => f.name).join(', ') || '',
      '작성일시': msg.createdAt?.toDate?.().toLocaleString() || '',
      '파일URL': msg.files?.map(f => f.url).join(', ') || ''
    }));
    
    // 대화방 정보 시트
    const roomInfo = [
      { '항목': '대화방명', '값': room.name },
      { '항목': '현장명', '값': room.siteName },
      { '항목': '총 메시지 수', '값': msgs.length },
      { '항목': '생성일', '값': room.createdAt?.toDate?.().toLocaleDateString() || '날짜 없음' },
      { '항목': '비밀번호', '값': room.password ? '있음' : '없음' }
    ];
    
    const wb = XLSX.utils.book_new();
    
    // 대화방 정보 시트
    const wsInfo = XLSX.utils.json_to_sheet(roomInfo);
    XLSX.utils.book_append_sheet(wb, wsInfo, '대화방정보');
    
    // 채팅 내역 시트
    const wsChat = XLSX.utils.json_to_sheet(data);
    XLSX.utils.book_append_sheet(wb, wsChat, '채팅내역');
    
    // 컬럼 너비 조정
    wsChat['!cols'] = [
      { width: 8 },   // 번호
      { width: 15 },  // 작성자
      { width: 50 },  // 내용
      { width: 30 },  // 첨부파일
      { width: 20 },  // 작성일시
      { width: 50 }   // 파일URL
    ];
    
    XLSX.writeFile(wb, `${room.name}_${room.siteName}_채팅내역.xlsx`);
  };

  return (
    <Box sx={{ p: 2 }}>
      <Box sx={{ display: 'flex', flexDirection: { xs: 'column', sm: 'row' }, gap: 2, mb: 2, alignItems: 'center' }}>
        <TextField
          placeholder="대화방/현장명 검색"
          value={search}
          onChange={e => setSearch(e.target.value)}
          size="small"
          sx={{ minWidth: 180, background: '#232634', borderRadius: 2, color: '#fff' }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon sx={{ color: '#90caf9' }} />
              </InputAdornment>
            )
          }}
        />
        <Select value={sort} onChange={e => setSort(e.target.value)} size="small" sx={{ minWidth: 120, background: '#232634', color: '#fff', borderRadius: 2 }}>
          <MenuItem value="recent">최신순</MenuItem>
          <MenuItem value="count">글 많은순</MenuItem>
        </Select>
      </Box>
      <Grid container spacing={2}>
        {filteredRooms.map(room => {
          const roomMsgs = messages[room.id] || [];
          const lastMsg = roomMsgs[0]?.content || '';
          const hasPassword = !!room.password;
          return (
            <Grid item xs={12} sm={6} md={12} key={room.id}>
              <Card sx={{ borderRadius: 3, boxShadow: 4, background: 'linear-gradient(90deg, #232634 60%, #1976d2 100%)', color: '#fff', cursor: 'pointer', transition: '0.2s', '&:hover': { boxShadow: 8, background: 'linear-gradient(90deg, #1976d2 60%, #232634 100%)', transform: 'scale(1.03)' } }}>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <Box onClick={() => hasPassword ? handlePasswordEnter(room) : onSelectRoom(room)}>
                      <Typography variant="h6" sx={{ fontWeight: 700 }}>{room.name}</Typography>
                      <Typography variant="body2" sx={{ color: '#90caf9' }}>현장: {room.siteName}</Typography>
                      <Typography variant="body2" sx={{ mt: 1, color: '#b0b0b0' }}>글 수: {roomMsgs.length}</Typography>
                      <Typography variant="body2" sx={{ color: '#b0b0b0' }}>최근: {lastMsg.length > 20 ? lastMsg.slice(0, 20) + '...' : lastMsg}</Typography>
                      {hasPassword ? <LockIcon fontSize="small" sx={{ color: '#ffb300', ml: 1 }} /> : <LockOpenIcon fontSize="small" sx={{ color: '#90caf9', ml: 1 }} />}
                    </Box>
                    <Box>
                      <Tooltip title="PDF로 내보내기"><IconButton color="inherit" onClick={() => handleExportPDF(room)}><PictureAsPdfIcon /></IconButton></Tooltip>
                      <Tooltip title="엑셀로 내보내기"><IconButton color="inherit" onClick={() => handleExportExcel(room)}><TableViewIcon /></IconButton></Tooltip>
                      {isAdmin && (
                        <>
                          <Tooltip title="수정"><IconButton color="inherit" onClick={() => handleEdit(room)}><EditIcon /></IconButton></Tooltip>
                          <Tooltip title="삭제"><IconButton color="error" onClick={(e) => {
                            e.stopPropagation();
                            handleDelete(room.id);
                          }}><DeleteIcon /></IconButton></Tooltip>
                        </>
                      )}
                      <Tooltip title="채팅 입장"><IconButton color="primary" onClick={() => hasPassword ? handlePasswordEnter(room) : onSelectRoom(room)}><ChatIcon /></IconButton></Tooltip>
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          );
        })}
      </Grid>
      {/* 대화방 수정 다이얼로그 */}
      <Dialog open={editDialog} onClose={() => setEditDialog(false)}>
        <DialogTitle>대화방 수정</DialogTitle>
        <DialogContent>
          <TextField label="대화방 이름" fullWidth sx={{ mb: 2 }} value={editName} onChange={e => setEditName(e.target.value)} />
          <TextField label="현장명" fullWidth sx={{ mb: 2 }} value={editSite} onChange={e => setEditSite(e.target.value)} />
          {isAdmin && (
            <TextField label="비밀번호(선택)" fullWidth value={editPassword} onChange={e => setEditPassword(e.target.value)} type="password" />
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditDialog(false)}>취소</Button>
          <Button onClick={handleEditSave} variant="contained">저장</Button>
        </DialogActions>
      </Dialog>
      {/* 비밀번호 입력 다이얼로그 */}
      <Dialog open={passwordDialog} onClose={() => setPasswordDialog(false)}>
        <DialogTitle>비밀번호 입력</DialogTitle>
        <DialogContent>
          <TextField label="비밀번호" fullWidth value={passwordInput} onChange={e => setPasswordInput(e.target.value)} type="password" />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setPasswordDialog(false)}>취소</Button>
          <Button onClick={handlePasswordCheck} variant="contained">입장</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default DiscussionRoomList; 