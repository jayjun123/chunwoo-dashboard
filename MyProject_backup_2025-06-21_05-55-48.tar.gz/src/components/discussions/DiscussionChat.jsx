import React, { useEffect, useRef, useState } from 'react';
import { Box, Typography, TextField, Button, Paper, Avatar, CircularProgress, IconButton, InputAdornment, Dialog, DialogContent, useMediaQuery, Menu, MenuItem } from '@mui/material';
import { collection, query, where, orderBy, onSnapshot, addDoc, serverTimestamp, deleteDoc, doc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { db, storage } from '../../firebase';
import { Send as SendIcon, AttachFile as AttachFileIcon, Image as ImageIcon, Download as DownloadIcon, Close as CloseIcon, MoreVert as MoreVertIcon, Delete as DeleteIcon } from '@mui/icons-material';
import { useTheme } from '@mui/material/styles';
import { useAuth } from '../../contexts/AuthContext';

const DiscussionChat = ({ roomId }) => {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [files, setFiles] = useState([]);
  const [previews, setPreviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [imageModal, setImageModal] = useState({ open: false, url: '' });
  const [messageMenu, setMessageMenu] = useState({ open: false, anchorEl: null, message: null });
  const messagesEndRef = useRef(null);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const { currentUser } = useAuth();

  useEffect(() => {
    if (!roomId) return;
    setLoading(true);
    const q = query(collection(db, 'discussions'), where('roomId', '==', roomId), orderBy('createdAt', 'asc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMessages(msgs);
      setLoading(false);
      setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
    });
    return () => unsubscribe();
  }, [roomId]);

  const handleSend = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() && files.length === 0) return;
    
    try {
      let uploadedFiles = [];
      
      // 파일 업로드
      for (const file of files) {
        const storageRef = ref(storage, `discussions/${roomId}/${Date.now()}_${file.name}`);
        await uploadBytes(storageRef, file);
        const url = await getDownloadURL(storageRef);
        uploadedFiles.push({ url, name: file.name, type: file.type });
      }
      
      // 메시지 저장
      await addDoc(collection(db, 'discussions'), {
        roomId,
        content: newMessage,
        files: uploadedFiles,
        createdAt: serverTimestamp(),
        author: currentUser?.displayName || currentUser?.email || '익명',
        authorId: currentUser?.uid || 'anonymous',
        authorEmail: currentUser?.email || ''
      });
      
      setNewMessage('');
      setFiles([]);
      setPreviews([]);
    } catch (error) {
      console.error('메시지 전송 중 오류:', error);
      alert('메시지 전송 중 오류가 발생했습니다.');
    }
  };

  const handleFileChange = (e) => {
    const selected = Array.from(e.target.files);
    setFiles(selected);
    setPreviews(selected.map(f => f.type.startsWith('image/') ? URL.createObjectURL(f) : ''));
  };

  const handleImageClick = (url) => {
    setImageModal({ open: true, url });
  };

  const handleMessageMenuOpen = (event, message) => {
    setMessageMenu({ open: true, anchorEl: event.currentTarget, message });
  };

  const handleMessageMenuClose = () => {
    setMessageMenu({ open: false, anchorEl: null, message: null });
  };

  const handleDeleteMessage = async () => {
    const message = messageMenu.message;
    if (!message) return;
    
    if (!window.confirm('이 메시지를 삭제하시겠습니까?')) {
      handleMessageMenuClose();
      return;
    }
    
    try {
      // 메시지 삭제
      await deleteDoc(doc(db, 'discussions', message.id));
      
      // 첨부 파일 삭제
      if (message.files && message.files.length > 0) {
        const deleteFilePromises = message.files.map(async (file) => {
          try {
            const fileRef = ref(storage, file.url);
            await deleteObject(fileRef);
          } catch (error) {
            console.error('파일 삭제 중 오류:', error);
          }
        });
        await Promise.all(deleteFilePromises);
      }
      
      handleMessageMenuClose();
    } catch (error) {
      console.error('메시지 삭제 중 오류:', error);
      alert('메시지 삭제 중 오류가 발생했습니다.');
    }
  };

  const canDeleteMessage = (message) => {
    return currentUser?.uid === message.authorId || 
           currentUser?.grade === '마스터' || 
           currentUser?.grade === '관리자';
  };

  return (
    <Box sx={{ p: isMobile ? 1 : 2, height: '100%', display: 'flex', flexDirection: 'column', background: 'linear-gradient(90deg, #232634 60%, #1976d2 100%)', borderRadius: 3, boxShadow: 4 }}>
      <Box sx={{ flex: 1, overflowY: 'auto', mb: 2, pr: isMobile ? 0 : 2 }}>
        {loading ? (
          <Box display="flex" justifyContent="center" alignItems="center" height="100%"><CircularProgress /></Box>
        ) : (
          messages.map((msg, idx) => {
            const isMine = currentUser?.uid === msg.authorId;
            return (
              <Box key={msg.id} sx={{ mb: 2, display: 'flex', flexDirection: 'column', alignItems: isMine ? 'flex-end' : 'flex-start', width: '100%' }}>
                <Paper
                  sx={{
                    p: isMobile ? 1 : 2,
                    borderRadius: 3,
                    background: isMine ? 'linear-gradient(90deg, #1976d2 60%, #232634 100%)' : '#fff',
                    color: isMine ? '#fff' : '#232634',
                    minWidth: 120,
                    maxWidth: isMobile ? '90vw' : 400,
                    boxShadow: isMine ? 6 : 2,
                    transition: 'box-shadow 0.2s',
                    mb: 0.5,
                    position: 'relative',
                    animation: 'fadeIn 0.4s',
                  }}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1, justifyContent: 'space-between' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <Avatar sx={{ width: 28, height: 28, mr: 1, bgcolor: isMine ? '#1976d2' : '#90caf9', color: '#fff', fontWeight: 700 }}>
                        {msg.author?.[0] || 'U'}
                      </Avatar>
                      <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>{msg.author || '익명'}</Typography>
                      <Typography variant="caption" sx={{ ml: 1, color: isMine ? '#fff' : '#888' }}>
                        {msg.createdAt?.toDate?.().toLocaleString() || ''}
                      </Typography>
                    </Box>
                    {canDeleteMessage(msg) && (
                      <IconButton
                        size="small"
                        onClick={(e) => handleMessageMenuOpen(e, msg)}
                        sx={{ color: isMine ? '#fff' : '#666' }}
                      >
                        <MoreVertIcon fontSize="small" />
                      </IconButton>
                    )}
                  </Box>
                  <Typography variant="body1" sx={{ mb: 1, wordBreak: 'break-all' }}>{msg.content}</Typography>
                  {msg.files && msg.files.length > 0 && (
                    <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 1 }}>
                      {msg.files.map((f, idx) => f.type.startsWith('image/') ? (
                        <img key={idx} src={f.url} alt={f.name} style={{ maxWidth: 80, borderRadius: 8, cursor: 'pointer', boxShadow: '0 2px 8px #1976d233' }} onClick={() => handleImageClick(f.url)} />
                      ) : (
                        <Button key={idx} href={f.url} target="_blank" startIcon={<DownloadIcon />} size="small">
                          {f.name}
                        </Button>
                      ))}
                    </Box>
                  )}
                </Paper>
              </Box>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </Box>
      <Box component="form" onSubmit={handleSend} sx={{ display: 'flex', gap: 2, alignItems: 'flex-end', mt: 2, flexDirection: isMobile ? 'column' : 'row', background: '#fff', borderRadius: 3, boxShadow: 2, p: isMobile ? 1 : 2 }}>
        <TextField
          fullWidth
          multiline
          minRows={isMobile ? 2 : 3}
          maxRows={isMobile ? 6 : 8}
          variant="outlined"
          placeholder="메시지 입력 또는 파일 첨부"
          value={newMessage}
          onChange={e => setNewMessage(e.target.value)}
          sx={{ background: '#f5f7fa', borderRadius: 2, fontSize: isMobile ? '1rem' : '1.1rem' }}
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton component="label">
                  <AttachFileIcon />
                  <input type="file" hidden multiple onChange={handleFileChange} />
                </IconButton>
              </InputAdornment>
            )
          }}
        />
        <Box sx={{ display: 'flex', gap: 1, alignItems: 'center', flexWrap: 'wrap' }}>
          {previews.map((url, idx) => url && <img key={idx} src={url} alt="미리보기" style={{ maxWidth: 60, borderRadius: 8, marginRight: 8, marginBottom: 4, boxShadow: '0 2px 8px #1976d233' }} />)}
        </Box>
        <Button type="submit" variant="contained" color="primary" size={isMobile ? 'medium' : 'large'} endIcon={<SendIcon />} sx={{ height: isMobile ? 48 : 56, fontWeight: 700, fontSize: isMobile ? '1rem' : '1.1rem', borderRadius: 2, minWidth: 100 }}>전송</Button>
      </Box>
      
      {/* 이미지 모달 */}
      <Dialog open={imageModal.open} onClose={() => setImageModal({ open: false, url: '' })} maxWidth="md">
        <DialogContent sx={{ p: 0, background: '#111' }}>
          <IconButton onClick={() => setImageModal({ open: false, url: '' })} sx={{ position: 'absolute', top: 8, right: 8, color: '#fff', zIndex: 2 }}><CloseIcon /></IconButton>
          <img src={imageModal.url} alt="확대보기" style={{ maxWidth: '90vw', maxHeight: '80vh', display: 'block', margin: '0 auto' }} />
        </DialogContent>
      </Dialog>
      
      {/* 메시지 메뉴 */}
      <Menu
        anchorEl={messageMenu.anchorEl}
        open={messageMenu.open}
        onClose={handleMessageMenuClose}
      >
        <MenuItem onClick={handleDeleteMessage} sx={{ color: '#f44336' }}>
          <DeleteIcon sx={{ mr: 1 }} />
          삭제
        </MenuItem>
      </Menu>
    </Box>
  );
};

export default DiscussionChat; 