import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { FaBars, FaTimes, FaUser, FaSignOutAlt, FaCog, FaBell } from 'react-icons/fa';
import '../../styles/Header.css';

const Header = () => {
  const { logout } = useAuth();
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  const menuItems = [
    { path: '/schedule', label: '일정관리', icon: '📅' },
    { path: '/overview', label: '주요현장', icon: '⭐' },
    { path: '/sites', label: '현장관리', icon: '🏗️' },
    { path: '/safety', label: '안전관리', icon: '⚠️' },
    { path: '/discussions', label: '토론의견', icon: '��' },
    { path: '/progress', label: '기성관리', icon: '💰' },
    { path: '/vendors', label: '거래처현황', icon: '💼' },
    { path: '/documents', label: '문서관리', icon: '📄' },
    { path: '/reports', label: '보고서', icon: '📊' }
  ];

  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      console.error('로그아웃 실패:', error);
    }
  };

  return (
    <header className="header">
      <div className="header-left">
        <button className="menu-toggle" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <FaTimes /> : <FaBars />}
        </button>
        <Link to="/" className="header-title">Chunwoo</Link>
      </div>

      <nav className={`header-nav ${isMenuOpen ? 'open' : ''}`}>
        <ul className="header-menu">
          {menuItems.map((item) => (
            <li key={item.path}>
              <Link 
                to={item.path} 
                className={location.pathname === item.path ? 'active' : ''}
                onClick={() => setIsMenuOpen(false)}
              >
                <span className="menu-icon">{item.icon}</span>
                {item.label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>

      <div className="header-right">
        <button className="icon-button">
          <FaBell />
          <span className="notification-badge">3</span>
        </button>
        
        <div className="user-menu">
          <button 
            className="user-menu-button"
            onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
          >
            <FaUser />
          </button>
          
          {isUserMenuOpen && (
            <div className="user-dropdown">
              <div className="user-info">
                <div className="user-name">관리자</div>
                <div className="user-email">admin@example.com</div>
              </div>
              <div className="dropdown-divider" />
              <button className="dropdown-item">
                <FaCog className="dropdown-icon" />
                계정 설정
              </button>
              <button className="dropdown-item logout" onClick={handleLogout}>
                <FaSignOutAlt className="dropdown-icon" />
                로그아웃
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header; 