import React, { useEffect, useState } from 'react';
import { Box, Typography, IconButton, Tooltip, Badge, Modal, Paper, Drawer, List, ListItem, ListItemIcon, ListItemText, Snackbar, Alert, Checkbox, Button, Popover } from '@mui/material';
import GroupIcon from '@mui/icons-material/Group';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import DoneAllIcon from '@mui/icons-material/DoneAll';
import MonetizationOnIcon from '@mui/icons-material/MonetizationOn';
import ForumIcon from '@mui/icons-material/Forum';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import ListAltIcon from '@mui/icons-material/ListAlt';
import SettingsIcon from '@mui/icons-material/Settings';
import WbSunnyIcon from '@mui/icons-material/WbSunny';
import MenuIcon from '@mui/icons-material/Menu';
import { collection, query, where, onSnapshot, addDoc, updateDoc, deleteDoc, doc, getDoc, orderBy } from 'firebase/firestore';
import { db } from '../../firebase';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import TextField from '@mui/material/TextField';
import CloseIcon from '@mui/icons-material/Close';
import Slide from '@mui/material/Slide';
import { format } from 'date-fns';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import InfoIcon from '@mui/icons-material/Info';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import EngineeringIcon from '@mui/icons-material/Engineering';
import SafetyHelmetIcon from '@mui/icons-material/SafetyCheck';

// props: 날짜, 날씨, 온도, 현장/기성/협의/안전/ToDo/관리 등 실시간 데이터, 클릭 이벤트 핸들러
const BottomBar = ({
  dateText,
  weatherIcon = <WbSunnyIcon sx={{ color: '#FFD600', fontSize: 20, verticalAlign: 'middle' }} />, // ☀️
  temperature,
  onWeather,
  onSites,
  onProgress,
  onDiscussion,
  onSafety,
  onTodo,
  onManage
}) => {
  const [stats, setStats] = useState({
    todaySites: 0,
    todayCompleted: 0,
    monthCompleted: 0,
    progressCount: 0,
    discussionCount: 0,
    safetyCount: 0,
    todoDone: 0,
    todoTotal: 0
  });

  // 팝업 상태 관리
  const [openProgress, setOpenProgress] = useState(false);
  const [openDiscussion, setOpenDiscussion] = useState(false);
  const [openSafety, setOpenSafety] = useState(false);
  const [openTodo, setOpenTodo] = useState(false);

  // 팝업 데이터 상태
  const [progressList, setProgressList] = useState([]);
  const [discussionList, setDiscussionList] = useState([]);
  const [safetyList, setSafetyList] = useState([]);
  const [todoList, setTodoList] = useState([]);

  // 햄버거 메뉴 Drawer 상태
  const [drawerOpen, setDrawerOpen] = useState(false);

  const navigate = useNavigate();

  const [error, setError] = useState('');

  const { currentUser } = useAuth();
  const [isMaster, setIsMaster] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    if (currentUser) {
      // 사용자 권한 확인
      const checkUserRole = async () => {
        try {
          const userDoc = await getDoc(doc(db, 'members', currentUser.uid));
          if (userDoc.exists()) {
            const userData = userDoc.data();
            setIsMaster(userData.role === 'master');
            setIsAdmin(userData.role === 'admin' || userData.role === 'master');
          }
        } catch (error) {
          console.error('사용자 권한 확인 실패:', error);
        }
      };
      checkUserRole();
    }
  }, [currentUser]);

  // 팝업 닫기 함수
  const handleClose = () => {
    setOpenProgress(false);
    setOpenDiscussion(false);
    setOpenSafety(false);
    setOpenTodo(false);
  };

  // 확장 상태 관리
  const [expandWeather, setExpandWeather] = useState(false);
  const [expandCenter, setExpandCenter] = useState(false);
  const [expandTodo, setExpandTodo] = useState(false);
  const [expandSettings, setExpandSettings] = useState(false);
  const [weatherLocation, setWeatherLocation] = useState('대구 달서구');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [weatherData, setWeatherData] = useState({
    current: {
      temp: 0,
      weather: '',
      icon: '01d'
    },
    daily: []
  });

  const [settingsTab, setSettingsTab] = useState(0); // 0:회원, 1:권한, 2:설정

  // 날씨 아이콘 매핑
  const weatherIcons = {
    '01d': <WbSunnyIcon sx={{ color: '#FFD600', fontSize: 28 }} />,
    '01n': <WbSunnyIcon sx={{ color: '#FFD600', fontSize: 28 }} />,
    '02d': <WbSunnyIcon sx={{ color: '#FFD600', fontSize: 28 }} />,
    '02n': <WbSunnyIcon sx={{ color: '#FFD600', fontSize: 28 }} />,
    '03d': <WbSunnyIcon sx={{ color: '#90CAF9', fontSize: 28 }} />,
    '03n': <WbSunnyIcon sx={{ color: '#90CAF9', fontSize: 28 }} />,
    '04d': <WbSunnyIcon sx={{ color: '#90CAF9', fontSize: 28 }} />,
    '04n': <WbSunnyIcon sx={{ color: '#90CAF9', fontSize: 28 }} />,
    '09d': <WbSunnyIcon sx={{ color: '#90CAF9', fontSize: 28 }} />,
    '09n': <WbSunnyIcon sx={{ color: '#90CAF9', fontSize: 28 }} />,
    '10d': <WbSunnyIcon sx={{ color: '#90CAF9', fontSize: 28 }} />,
    '10n': <WbSunnyIcon sx={{ color: '#90CAF9', fontSize: 28 }} />,
    '11d': <WbSunnyIcon sx={{ color: '#FFD600', fontSize: 28 }} />,
    '11n': <WbSunnyIcon sx={{ color: '#FFD600', fontSize: 28 }} />,
    '13d': <WbSunnyIcon sx={{ color: '#90CAF9', fontSize: 28 }} />,
    '13n': <WbSunnyIcon sx={{ color: '#90CAF9', fontSize: 28 }} />,
    '50d': <WbSunnyIcon sx={{ color: '#90CAF9', fontSize: 28 }} />,
    '50n': <WbSunnyIcon sx={{ color: '#90CAF9', fontSize: 28 }} />
  };

  // 날씨 상태 한글 매핑
  const weatherStatus = {
    'Clear': '맑음',
    'Clouds': '구름',
    'Rain': '비',
    'Snow': '눈',
    'Thunderstorm': '번개',
    'Drizzle': '이슬비',
    'Mist': '안개'
  };

  // 날짜를 'YYYY. M. D (요일)' 한글로 포맷팅하는 함수
  function formatDate(date) {
    const week = ['일', '월', '화', '수', '목', '금', '토'];
    const d = new Date(date);
    return `${d.getFullYear()}. ${d.getMonth() + 1}. ${d.getDate()} (${week[d.getDay()]})`;
  }

  // 기상청 날씨 코드 변환 함수(상태/아이콘)
  const getWeatherStatus = (code) => {
    const status = {
      '0': '맑음',
      '1': '구름많음',
      '2': '흐림',
      '3': '비',
      '4': '소나기',
      '5': '비/눈',
      '6': '눈',
      '7': '눈날림'
    };
    return status[code] || '날씨 정보 없음';
  };
  const getWeatherIcon = (code) => {
    const icons = {
      '0': '01d', // 맑음
      '1': '02d', // 구름많음
      '2': '04d', // 흐림
      '3': '10d', // 비
      '4': '09d', // 소나기
      '5': '13d', // 비/눈
      '6': '13d', // 눈
      '7': '13d'  // 눈날림
    };
    return icons[code] || '01d';
  };

  // 대구 달서구 nx, ny: 89, 90
  const getLocationCoords = (location) => {
    if (location.includes('대구') && location.includes('달서')) return { nx: 89, ny: 90 };
    if (location.includes('서울')) return { nx: 55, ny: 127 };
    // 기타 지역 추가 가능
    return { nx: 89, ny: 90 };
  };
  const fetchWeatherData = async (location) => {
    try {
      const { nx, ny } = getLocationCoords(location);
      const response = await fetch(
        `http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getVilageFcst?serviceKey=${import.meta.env.VITE_WEATHER_API_KEY}&numOfRows=1000&pageNo=1&dataType=JSON&base_date=${format(new Date(), 'yyyyMMdd')}&base_time=0500&nx=${nx}&ny=${ny}`
      );
      const data = await response.json();
      const weatherItems = data?.response?.body?.items?.item || [];
      // 주간 날씨 가공
      const days = Array(7).fill(0).map((_, i) => {
        const d = new Date();
        d.setDate(d.getDate() + i);
        const dateStr = format(d, 'yyyyMMdd');
        const dayItems = weatherItems.filter(item => item.fcstDate === dateStr);
        const tempItem = dayItems.find(item => item.category === 'TMP');
        const skyItem = dayItems.find(item => item.category === 'SKY');
        return {
          date: d,
          temp: tempItem ? Math.round(parseFloat(tempItem.fcstValue)) : '-',
          icon: getWeatherIcon(skyItem?.fcstValue),
          weather: getWeatherStatus(skyItem?.fcstValue)
        };
      });
      const currentWeather = weatherItems.find(item => item.category === 'PTY' || item.category === 'SKY');
      const currentTemp = weatherItems.find(item => item.category === 'TMP');
      setWeatherData({
        current: {
          temp: currentTemp ? Math.round(parseFloat(currentTemp.fcstValue)) : '-',
          weather: getWeatherStatus(currentWeather?.fcstValue),
          icon: getWeatherIcon(currentWeather?.fcstValue)
        },
        daily: days
      });
    } catch (error) {
      console.error('날씨 데이터 조회 실패:', error);
      setError('날씨 정보를 불러오는데 실패했습니다.');
    }
  };

  // 날씨 데이터 주기적 갱신
  useEffect(() => {
    fetchWeatherData(weatherLocation);
    const interval = setInterval(() => {
      fetchWeatherData(weatherLocation);
    }, 1800000); // 30분마다 갱신

    return () => clearInterval(interval);
  }, [weatherLocation]);

  useEffect(() => {
    // 달력에서 전달된 금일 현장 수 업데이트
    const handleDashboardUpdate = (event) => {
      if (event.detail.todaySites !== undefined) {
        setStats(prev => ({ ...prev, todaySites: event.detail.todaySites }));
      }
    };

    window.addEventListener('updateDashboard', handleDashboardUpdate);
    return () => window.removeEventListener('updateDashboard', handleDashboardUpdate);
  }, []);

  useEffect(() => {
    // 기성현황 fetch + 최근 5개
    const unsubProgress = onSnapshot(collection(db, 'progress'), (snapshot) => {
      const arr = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      const filtered = arr.filter(item => !['샘플','테스트','임시'].some(word => (item.siteId||item.title||item.content||'').includes(word)));
      setStats(prev => ({ ...prev, progressCount: filtered.length }));
      setProgressList(filtered.slice(-5).reverse());
    }, (err) => setError('기성현황 데이터를 불러오는 중 오류가 발생했습니다.'));
    
    // 협의새글 fetch + 최근 5개
    const unsubDiscussion = onSnapshot(collection(db, 'discussions'), (snapshot) => {
      const arr = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      const filtered = arr.filter(item => !['샘플','테스트','임시'].some(word => (item.title||item.content||'').includes(word)));
      setStats(prev => ({ ...prev, discussionCount: filtered.length }));
      setDiscussionList(filtered.slice(-5).reverse());
    }, (err) => setError('협의새글 데이터를 불러오는 중 오류가 발생했습니다.'));
    
    // 안전새글 fetch + 최근 5개
    const unsubSafety = onSnapshot(collection(db, 'safety'), (snapshot) => {
      const arr = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      const filtered = arr.filter(item => !['샘플','테스트','임시'].some(word => (item.title||item.content||'').includes(word)));
      setStats(prev => ({ ...prev, safetyCount: filtered.length }));
      setSafetyList(filtered.slice(-5).reverse());
    }, (err) => setError('안전새글 데이터를 불러오는 중 오류가 발생했습니다.'));
    
    // ToDoList fetch + 최근 5개
    const unsubTodos = onSnapshot(collection(db, 'todos'), (snapshot) => {
      const arr = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      const filtered = arr.filter(item => !['샘플','테스트','임시'].some(word => (item.text||item.title||'').includes(word)));
      const done = filtered.filter(t => t.completed).length;
      setStats(prev => ({ ...prev, todoDone: done, todoTotal: filtered.length }));
      setTodoList(filtered.slice(-5).reverse());
    }, (err) => setError('ToDoList 데이터를 불러오는 중 오류가 발생했습니다.'));

    return () => {
      unsubProgress();
      unsubDiscussion();
      unsubSafety();
      unsubTodos();
    };
  }, []);

  // ToDo 확장 팝업용 스타일
  const todoPopupStyle = {
    background: '#fff',
    borderRadius: 12,
    boxShadow: '0 4px 24px rgba(0,0,0,0.12)',
    border: '1.5px solid #222',
    padding: '24px 20px 20px 20px',
    minWidth: 320,
    maxWidth: 400,
    width: '95%',
    margin: '0 auto',
    position: 'relative',
    fontFamily: 'inherit',
    backgroundImage: 'repeating-linear-gradient(to bottom, #fff, #fff 32px, #eee 32px, #eee 34px)',
  };

  // 요일/날짜 계산 함수
  const getWeekDates = () => {
    const today = new Date();
    const week = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date(today);
      d.setDate(today.getDate() + i);
      week.push({
        date: d,
        day: ['일','월','화','수','목','금','토'][d.getDay()],
        label: `${d.getMonth() + 1}/${d.getDate()}`
      });
    }
    return week;
  };
  const weekDates = getWeekDates();

  // 확장 패널 동시 오픈 방지
  const handleOpenPanel = (panel) => {
    setExpandWeather(panel === 'weather');
    setExpandCenter(panel === 'center');
    setExpandTodo(panel === 'todo');
  };

  // 확장 패널 닫기: ESC, 외부 클릭 지원
  useEffect(() => {
    function handleKeyDown(e) {
      if (e.key === 'Escape') {
        setExpandCenter(false);
        setExpandWeather(false);
        setExpandTodo(false);
        setExpandSettings(false);
      }
    }
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  function handleBackdropClick(e, closeFn) {
    if (e.target === e.currentTarget) {
      closeFn(false);
    }
  }

  const [todoInput, setTodoInput] = useState('');

  const handleAddTodo = async (e) => {
    e.preventDefault();
    if (!todoInput.trim()) return;

    try {
      await addDoc(collection(db, 'todos'), {
        text: todoInput.trim(),
        completed: false,
        userId: currentUser.uid,
        createdAt: new Date(),
        updatedAt: new Date()
      });
      setTodoInput('');
    } catch (error) {
      console.error('할일 추가 실패:', error);
      setError('할일을 추가하는데 실패했습니다.');
    }
  };

  const handleToggleTodo = async (item) => {
    try {
      await updateDoc(doc(db, 'todos', item.id), {
        completed: !item.completed,
        updatedAt: new Date()
      });
    } catch (error) {
      console.error('할일 상태 변경 실패:', error);
      setError('할일 상태를 변경하는데 실패했습니다.');
    }
  };

  const handleEditTodo = async (item) => {
    try {
      await updateDoc(doc(db, 'todos', item.id), {
        text: item.text,
        updatedAt: new Date()
      });
    } catch (error) {
      console.error('할일 수정 실패:', error);
      setError('할일을 수정하는데 실패했습니다.');
    }
  };

  const handleDeleteTodo = async (item) => {
    try {
      await deleteDoc(doc(db, 'todos', item.id));
    } catch (error) {
      console.error('할일 삭제 실패:', error);
      setError('할일을 삭제하는데 실패했습니다.');
    }
  };

  // 관리자/마스터 권한 체크 함수
  function isAdminOrMaster(user) {
    if (!user) return false;
    if (user.role === 'master' || user.role === 'admin') return true;
    if (user.email === 'fire8803@naver.com' || user.uid === 'HpF5IrlTscYbWPsUhtdzV05sjbF2') return true;
    return false;
  }
  const isAdminOrMasterUser = isAdminOrMaster(currentUser);

  const [anchorElSettings, setAnchorElSettings] = useState(null);
  const [anchorElWeather, setAnchorElWeather] = useState(null);

  // 설정 아이콘 클릭 핸들러
  const handleSettingsIconClick = (e) => {
    setAnchorElSettings(e.currentTarget);
  };
  const handleSettingsClose = () => {
    setAnchorElSettings(null);
  };
  // 날씨 아이콘 클릭 핸들러
  const handleWeatherIconClick = (e) => {
    setAnchorElWeather(e.currentTarget);
  };
  const handleWeatherClose = () => {
    setAnchorElWeather(null);
  };

  return (
    <Box sx={{
      width: '100%',
      bgcolor: '#23242a',
      color: '#fff',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      px: { xs: 1, md: 3 },
      py: 1,
      minHeight: 44,
      fontSize: 15,
      position: 'fixed',
      left: 0,
      bottom: 0,
      zIndex: 1201,
      boxShadow: '0 -2px 8px rgba(0,0,0,0.08)'
    }}>
      {/* 왼쪽: 날짜/온도/날씨(아이콘) 전체 클릭 시 확장 */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flex: '0 0 auto', minWidth: 220, cursor: 'pointer' }} onClick={() => handleOpenPanel('weather')}>
        <Typography sx={{ fontWeight: 500, fontSize: 15 }}>{formatDate(currentDate)}</Typography>
        <Typography sx={{ fontSize: 15, ml: 0.5 }}>{weatherData.current?.temp}°C</Typography>
        <Box sx={{ display: 'flex', alignItems: 'center', ml: 1 }}>{weatherIcons[weatherData.current?.icon]}</Box>
      </Box>
      {/* WeatherPanel: 하단바 위로 확장되는 날씨 패널 */}
      <Slide direction="up" in={expandWeather} mountOnEnter unmountOnExit>
        <Box sx={{ 
          position: 'fixed', 
          left: 0, 
          right: 0, 
          bottom: 44, 
          zIndex: 1302, 
          bgcolor: '#23242a', 
          color: '#fff', 
          boxShadow: 3, 
          borderRadius: '16px 16px 0 0', 
          p: 3, 
          maxWidth: '100vw', 
          minWidth: 0, 
          width: '100%', 
          margin: '0 auto', 
          minHeight: 220, 
          overflowX: 'auto',
          overflowY: 'visible',
        }} onClick={e => handleBackdropClick(e, setExpandWeather)}>
          <IconButton onClick={() => setExpandWeather(false)} sx={{ position: 'absolute', right: 16, top: 16, color: '#fff', zIndex: 1400 }}><CloseIcon /></IconButton>
          <Typography variant="h6" sx={{ mb: 2, fontWeight: 700 }}>{formatDate(currentDate)} ~ {formatDate(new Date(Date.now() + 4*24*60*60*1000))} (5일간)</Typography>
          <Box sx={{ display: 'flex', gap: 2, alignItems: 'center', mb: 2 }}>
            <TextField size="small" variant="outlined" value={weatherLocation} onChange={e => setWeatherLocation(e.target.value)} sx={{ bgcolor: '#fff', borderRadius: 1, minWidth: 180 }} placeholder="지역명(예: 서울)" />
            <Typography sx={{ color: '#aaa', fontSize: 13 }}>기상청 실시간 날씨 정보</Typography>
          </Box>
          {/* 7일간 날씨 카드형 가로 스크롤 */}
          <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', mt: 2, overflowX: 'auto', pb: 1 }}>
            {weatherData.daily.map((day, i) => (
              <Box key={i} sx={{ bgcolor: '#2a2b32', borderRadius: 2, p: 2, minWidth: 90, textAlign: 'center', flex: '0 0 auto', boxShadow: 2 }}>
                <Typography sx={{ fontSize: 13, mb: 0.5 }}>{['일','월','화','수','목','금','토'][day.date.getDay()]}</Typography>
                <Typography sx={{ fontSize: 12, color: '#aaa', mb: 1 }}>{`${day.date.getMonth() + 1}/${day.date.getDate()}`}</Typography>
                {weatherIcons[day.icon]}
                <Typography sx={{ fontSize: 15, fontWeight: 700, mt: 1 }}>{day.temp}°C</Typography>
                <Typography sx={{ fontSize: 12, color: '#aaa' }}>{weatherStatus[day.weather] || '날씨 정보 없음'}</Typography>
              </Box>
            ))}
          </Box>
        </Box>
      </Slide>
      {/* 중앙: 금일현장/기성/협의/안전 */}
      <Box sx={{ 
        display: 'flex', 
        alignItems: 'center', 
        gap: { xs: 2, md: 4 }, 
        flex: 1, 
        justifyContent: 'center', 
        cursor: 'pointer' 
      }} onClick={() => setExpandCenter(v => !v)}>
        <Typography sx={{ fontSize: 15, display: 'flex', alignItems: 'center', gap: 0.5 }}>
          <EngineeringIcon sx={{ fontSize: 18, color: '#FFD600', mr: 0.5 }} /> 금일현장 {stats.todaySites ?? 0}
        </Typography>
        <Typography sx={{ fontSize: 15, display: 'flex', alignItems: 'center', gap: 0.5 }}>
          <TrendingUpIcon sx={{ fontSize: 18, color: '#4FC3F7', mr: 0.5 }} /> {new Date().getMonth() + 1}월기성 {stats.progressCount ?? 0}
        </Typography>
        <Typography sx={{ fontSize: 15, display: 'flex', alignItems: 'center', gap: 0.5 }}>
          <ForumIcon sx={{ fontSize: 18, color: '#FF7043', mr: 0.5 }} /> 협의새글 {stats.discussionCount ?? 0}
        </Typography>
        <Typography sx={{ fontSize: 15, display: 'flex', alignItems: 'center', gap: 0.5 }}>
          <SafetyHelmetIcon sx={{ fontSize: 18, color: '#81C784', mr: 0.5 }} /> 안전새글 {stats.safetyCount ?? 0}
        </Typography>
      </Box>
      {/* 중앙 확장 패널: 금일현장/기성/협의/안전 상세 */}
      <Slide direction="up" in={expandCenter} mountOnEnter unmountOnExit>
        <Box
          sx={{
            position: 'fixed',
            left: 0,
            right: 0,
            bottom: 44,
            zIndex: 1202,
            bgcolor: '#23242a',
            color: '#fff',
            boxShadow: 3,
            borderRadius: '16px 16px 0 0',
            p: 3,
            maxWidth: 900,
            margin: '0 auto',
            minHeight: 260
          }}
          onClick={e => handleBackdropClick(e, setExpandCenter)}
        >
          <IconButton 
            onClick={() => setExpandCenter(false)} 
            sx={{ position: 'absolute', right: 16, top: 16, color: '#fff' }}
          >
            <CloseIcon />
          </IconButton>
          <Typography variant="h6" sx={{ mb: 2, fontWeight: 700 }}>
            금일현장/기성/협의/안전 실시간 현황
          </Typography>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 3 }}>
            {/* 금일현장 카드 */}
            <Box sx={{ flex: 1, minWidth: 200, bgcolor: '#2a2b32', borderRadius: 2, p: 2 }}>
              <Typography sx={{ fontWeight: 600, mb: 1 }}>금일현장</Typography>
              <Typography sx={{ fontSize: 22, fontWeight: 700, color: '#FFD600' }}>{stats.todaySites ?? 0}</Typography>
              <Box sx={{ mt: 1 }}>
                {progressList.length === 0 ? (
                  <Typography sx={{ color: '#aaa', fontSize: 14 }}>금일 현장 데이터 없음</Typography>
                ) : (
                  progressList.map(item => (
                    <Box key={item.id} sx={{ fontSize: 14, color: '#fff', mb: 0.5 }}>
                      {item.siteName || item.title || '-'}
                    </Box>
                  ))
                )}
              </Box>
            </Box>
            {/* 기성 카드 */}
            <Box sx={{ flex: 1, minWidth: 200, bgcolor: '#2a2b32', borderRadius: 2, p: 2 }}>
              <Typography sx={{ fontWeight: 600, mb: 1 }}>기성</Typography>
              <Typography sx={{ fontSize: 22, fontWeight: 700, color: '#4FC3F7' }}>{stats.progressCount ?? 0}</Typography>
              <Box sx={{ mt: 1 }}>
                {progressList.length === 0 ? (
                  <Typography sx={{ color: '#aaa', fontSize: 14 }}>기성 데이터 없음</Typography>
                ) : (
                  progressList.map(item => (
                    <Box key={item.id} sx={{ fontSize: 14, color: '#fff', mb: 0.5 }}>
                      {item.title || '-'} / {item.amount ? `${item.amount.toLocaleString()}원` : ''}
                    </Box>
                  ))
                )}
              </Box>
            </Box>
            {/* 협의 카드 */}
            <Box sx={{ flex: 1, minWidth: 200, bgcolor: '#2a2b32', borderRadius: 2, p: 2 }}>
              <Typography sx={{ fontWeight: 600, mb: 1 }}>협의새글</Typography>
              <Typography sx={{ fontSize: 22, fontWeight: 700, color: '#FF7043' }}>{stats.discussionCount ?? 0}</Typography>
              <Box sx={{ mt: 1 }}>
                {discussionList.length === 0 ? (
                  <Typography sx={{ color: '#aaa', fontSize: 14 }}>협의 데이터 없음</Typography>
                ) : (
                  discussionList.map(item => (
                    <Box key={item.id} sx={{ fontSize: 14, color: '#fff', mb: 0.5 }}>
                      {item.title || '-'}
                    </Box>
                  ))
                )}
              </Box>
            </Box>
            {/* 안전 카드 */}
            <Box sx={{ flex: 1, minWidth: 200, bgcolor: '#2a2b32', borderRadius: 2, p: 2 }}>
              <Typography sx={{ fontWeight: 600, mb: 1 }}>안전새글</Typography>
              <Typography sx={{ fontSize: 22, fontWeight: 700, color: '#81C784' }}>{stats.safetyCount ?? 0}</Typography>
              <Box sx={{ mt: 1 }}>
                {safetyList.length === 0 ? (
                  <Typography sx={{ color: '#aaa', fontSize: 14 }}>안전 데이터 없음</Typography>
                ) : (
                  safetyList.map(item => (
                    <Box key={item.id} sx={{ fontSize: 14, color: '#fff', mb: 0.5 }}>
                      {item.title || '-'}
                    </Box>
                  ))
                )}
              </Box>
            </Box>
          </Box>
        </Box>
      </Slide>
      {/* 우측: ToDoList + 설정 아이콘 */}
      <Box sx={{ 
        display: 'flex', 
        alignItems: 'center', 
        gap: 2, 
        flex: '0 0 auto', 
        minWidth: 120, 
        justifyContent: 'flex-end' 
      }}>
        <Typography 
          sx={{ fontSize: 15, cursor: 'pointer' }} 
          onClick={() => setExpandTodo(v => !v)}
        >
          ToDoList {stats.todoDone ?? 0}/{stats.todoTotal ?? 0}
        </Typography>
        <IconButton size="small" onClick={handleSettingsIconClick} sx={{ color: '#fff' }}>
          <SettingsIcon />
        </IconButton>
        <Popover
          open={Boolean(anchorElSettings)}
          anchorEl={anchorElSettings}
          onClose={handleSettingsClose}
          anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
          transformOrigin={{ vertical: 'bottom', horizontal: 'center' }}
          PaperProps={{ sx: { bgcolor: '#23242a', color: '#fff', p: 2, borderRadius: 2, minWidth: 180 } }}
        >
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
            <Button variant="contained" color="primary" size="small" sx={{ fontWeight: 600 }} onClick={() => { handleSettingsClose(); navigate('/users'); }}>회원관리</Button>
            <Button variant="contained" color="primary" size="small" sx={{ fontWeight: 600 }} onClick={() => { handleSettingsClose(); navigate('/users'); }}>권한관리</Button>
            <Button variant="contained" color="primary" size="small" sx={{ fontWeight: 600 }} onClick={() => { handleSettingsClose(); navigate('/settings'); }}>설정</Button>
          </Box>
        </Popover>
      </Box>
      {/* ToDoList 확장 패널: ToDoList 바로 위에서 슬라이드로 확장, 전체리스트 버튼 추가 */}
      {expandTodo && (
        <Box sx={{ position: 'fixed', right: 32, bottom: 100, zIndex: 1300 }}>
          <Button variant="contained" color="primary" size="medium" sx={{ borderRadius: 8, fontWeight: 700 }} onClick={() => navigate('/todo/all')}>
            전체리스트
          </Button>
        </Box>
      )}
      <Slide direction="up" in={expandTodo} mountOnEnter unmountOnExit>
        <Box sx={{ position: 'fixed', right: 20, bottom: 44 + 48, zIndex: 1202, bgcolor: '#23242a', color: '#fff', boxShadow: 3, borderRadius: '16px 16px 0 0', p: 3, maxWidth: 500, margin: '0 0 0 auto', minHeight: 260 }} onClick={e => handleBackdropClick(e, setExpandTodo)}>
          <IconButton 
            onClick={() => setExpandTodo(false)} 
            sx={{ position: 'absolute', right: 16, top: 16, color: '#fff' }}
          >
            <CloseIcon />
          </IconButton>
          <Typography variant="h6" sx={{ mb: 2, fontWeight: 700 }}>
            ToDoList 실시간 관리
          </Typography>
          {/* ToDo 입력/추가 */}
          <Box sx={{ display: 'flex', gap: 1, mb: 2 }}>
            <TextField
              variant="standard"
              placeholder="할 일 추가"
              value={todoInput}
              onChange={e => setTodoInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && todoInput?.trim()) handleAddTodo(e); }}
              InputProps={{
                disableUnderline: true,
                style: {
                  background: 'transparent',
                  border: 'none',
                  boxShadow: 'none',
                  color: '#fff',
                  padding: 0
                }
              }}
              sx={{
                flex: 1,
                minWidth: 0,
                fontSize: '1rem',
                background: 'transparent',
                border: 'none',
                boxShadow: 'none',
                color: '#fff',
                '& input': {
                  background: 'transparent',
                  border: 'none',
                  boxShadow: 'none',
                  color: '#fff',
                  padding: 0
                }
              }}
            />
            <Button
              variant="contained"
              color="primary"
              sx={{ minWidth: 80, fontWeight: 600 }}
              onClick={e => handleAddTodo(e)}
              disabled={!todoInput?.trim()}
            >
              추가
            </Button>
          </Box>
          {/* ToDo 리스트 */}
          <Box sx={{ maxHeight: 260, overflowY: 'auto', pr: 1 }}>
            {todoList.length === 0 ? (
              <Typography sx={{ color: '#aaa', fontSize: 14 }}>할 일이 없습니다.</Typography>
            ) : (
              todoList.map(item => (
                <Box key={item.id} sx={{ display: 'flex', alignItems: 'center', mb: 1, p: 1, borderRadius: 1, bgcolor: item.completed ? '#333' : '#2a2b32' }}>
                  <Checkbox
                    checked={!!item.completed}
                    onChange={() => handleToggleTodo(item)}
                    sx={{ color: '#FFD600' }}
                  />
                  <Typography sx={{ flex: 1, fontSize: 15, textDecoration: item.completed ? 'line-through' : 'none', color: item.completed ? '#aaa' : '#fff' }}>
                    {item.text}
                  </Typography>
                  <IconButton size="small" onClick={() => handleEditTodo(item)} sx={{ color: '#4FC3F7' }}>
                    <EditIcon fontSize="small" />
                  </IconButton>
                  <IconButton size="small" onClick={() => handleDeleteTodo(item)} sx={{ color: '#FF7043' }}>
                    <DeleteIcon fontSize="small" />
                  </IconButton>
                </Box>
              ))
            )}
          </Box>
        </Box>
      </Slide>
    </Box>
  );
};

export default BottomBar; 